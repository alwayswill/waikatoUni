package com.android.will.wnews.model;

/**
 * Paper      : COMP548-15A(HAM)
 * Student ID : 125491
 * Name       : Shuzu Li
 * Email      : lishuzu@gmail.com
 * <p/>
 * Created by Shuzu Li on 20/05/15.
 */
public class Category {
    public String name;
    public int id;
}
