package com.android.will.wnews.interfaces;

import com.android.will.wnews.model.News;


public interface NewsSelectionListener {
	public void onNewsSelected(News news);
}
