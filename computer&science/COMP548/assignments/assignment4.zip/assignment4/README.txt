Plateform:Android 5.1
API level 22
Device: Nexus 5
Android studio version: 1.2.1.1

Test account:
Username:shuzuli
password:1254291